jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 banfSet in the list

sap.ui.require([
	"sap/ui/test/Opa5",
	"zqm/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zqm/test/integration/pages/App",
	"zqm/test/integration/pages/Browser",
	"zqm/test/integration/pages/Master",
	"zqm/test/integration/pages/Detail",
	"zqm/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zqm.view."
	});

	sap.ui.require([
		"zqm/test/integration/MasterJourney",
		"zqm/test/integration/NavigationJourney",
		"zqm/test/integration/NotFoundJourney",
		"zqm/test/integration/BusyJourney",
		"zqm/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});